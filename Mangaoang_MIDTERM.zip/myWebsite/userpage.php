<?php 
include 'includes/header.php'; 
if (!is_logged_in()) {
    header("Location: login.php?message=Please log in to view this page.");
    die();
}
else{
    $id = $_SESSION['id'];
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    //get data from pages table where id = session id
    $statement = $conn->prepare('SELECT * FROM pages
                                 WHERE id=:id');
    $statement->bindParam(':id',$id, PDO::PARAM_INT);
    $statement->execute();
    $row = $statement->fetch();

    if (empty($row)) {
        $statement = $conn->prepare('INSERT INTO pages (id)
                                                 values(:id)');
        $statement->bindParam(':id',$id, PDO::PARAM_INT);
        $statement->execute();
        header("Location: userpage.php");
        die();
    }
    else {
        $fname = $row['fname'];
        $mname = $row['mname'];
        $lname = $row['lname'];
        $a = array(
            $row['q1'],
            $row['q2'],
            $row['q3'],
            $row['q4'],
            $row['q5'],
            $row['q6'],
            $row['q7'],
            $row['q8'],
            $row['q9'],
            $row['q10']
        );
    }
}
?>
<div>
   <ul class="w3-navbar w3-opacity w3-hover-opacity-off w3-medium">
      <li class="w3-left" style="width:70% !important"><a href="index.php">Home</a></li>
      <li class="w3-right" style="width:15% !important"><a href="logout.php">Logout</a></li>
      <li class="w3-right" style="width:15% !important"><a href="userpage.php">My Account</a></li>
   </ul>
</div>

<div class="w3-content" id="userpage">
    <?php 
        if(!empty($fname)){
            echo "<h1 class='w3-center'>Welcome Back $fname!</h1>";
        }
        else{
            echo "<h1>Welcome Back!</h1>";
        }
        if (!empty($message)) {echo "<div class='w3-red'><h5>$message</h5></div>";}
     ?>
     <form action="updateuser.php" method="post" id="answers">
         <ul style="list-style-type: none">
         <?php 
            $questions = $conn->query('select * from questions');
            foreach ($questions as $key => $question) {
                echo "<li>";
                echo "<label for='a";
                echo $question['id'];
                echo "'>";
                echo $question['question'];
                echo "</label><br>";
                echo "<textarea form='answers' name='a";
                echo $question['id'];
                echo "' id='a";
                echo $question['id'];
                echo "' rows=5 cols=50 wrap='soft' style='resize:none;'>" ;
                echo $a[$question['id'] - 1];
                echo "</textarea>";
                echo "</li>";
            }
          ?>
            <li>
              <label for="fname">
                First Name
              </label>
              <input type="text" name="fname" id="fname" value="<?php echo $fname; ?>" />
            </li>
            <li>
              <label for="mname">
                Middle Name
              </label>
              <input type="text" name="mname" id="mname" value="<?php echo $mname; ?>" />
            </li>
            <li>
              <label for="lname">
                Last Name
              </label>
              <input type="text" name="lname" id="lname" value="<?php echo $lname; ?>" />
            </li>
            <li><button type="submit" />Update</button></li>
         </ul>
     </form>
</div>
<p align="right" style="color:red;"><a href="delete.php">Delete account</a></p>
<?php include 'includes/footer.php'; ?>