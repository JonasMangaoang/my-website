<?php 
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (!empty($_POST['username']) 
        && !empty($_POST['password']) 
        && !empty($_POST['email_address'])) {
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email_address = $_POST['email_address'];

        $statement = $conn->prepare('SELECT * FROM users
                                     WHERE username=:username');
        $statement->bindParam(':username',$username, PDO::PARAM_STR);
        $statement->execute();
        $row = $statement->fetch();

        if (empty($row)) {
            $statement = $conn->prepare('INSERT INTO users (username, password, email_address)
                                                     values(:username,:password,:email_address)');
            $statement->bindParam(':username',$username, PDO::PARAM_STR);
            $statement->bindParam(':password',$password, PDO::PARAM_STR);
            $statement->bindParam(':email_address',$email_address, PDO::PARAM_STR);
            $statement->execute();
            header("Location: login.php?message=Login to get started.");
        }
        else {
            header("Location: login.php?message=account already exists.");
        }
    }
    else{
        header("Location: signup.php?message=incomplete details");
    }
}
else {
    header("Location: signup.php?message=invalid access");
}

 ?>