<?php 

session_start();

$config = array('DB_USERNAME' => 'root',
                'DB_PASSWORD' => '123zxc$V');

 ?>