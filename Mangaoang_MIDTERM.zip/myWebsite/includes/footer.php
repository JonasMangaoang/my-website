<footer class="w3-container w3-light-blue w3-padding-16">
    <p>Footer</p>
    <p>Jonas B. Mangaoang</p>
    <p>BS Computer Engineering</p>
    <p>First Asia Institute of Technology and Humanities</p>
</footer>
</body>
</html>