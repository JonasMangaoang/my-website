<?php 
include 'includes/functions.php'; 
$get = $_GET;
if (!empty($get['message'])) {
    $message = $get['message'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Website</title>
    <link rel="stylesheet" type="text/css" href="styles/style.css">
</head>
<body>
<header class="w3-card-4 w3-teal">
    <h1 align="center"><a href="index.php" style="text-decoration: none">My Website Header</a></h1>
</header>