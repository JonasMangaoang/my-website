<?php 
require 'config.php';

function is_logged_in()
{
    return isset($_SESSION['username']);
}

#variable declarations
try {
    $conn = new PDO('mysql:host=localhost;dbname=mywebsite',
            $config['DB_USERNAME'],
            $config['DB_PASSWORD']);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // $questions = $conn->query('select * from questions');
    // foreach ($questions as $key => $question) {
    //     echo "<p>";
    //     echo "Question #" . $question['id'] . "</br>";
    //     echo $question['question'];
    //     echo "</p>";
    // }
    
    // $users = $conn->query('select * from users');
    // foreach ($users as $key => $user) {
    //     echo "<p>";
    //     echo "username: " . $user['username'] . "</br>";
    //     echo "email: " . $user['email_address'];
    //     echo "</p>";
    // }
    
    // $pages = $conn->query('select * from pages');
    // foreach ($pages as $key => $page) {
    //     echo "<p>";
    //     echo "<h4>" . $page['fname'] . " "
    //                 . $page['mname'] . " "
    //                 . $page['lname'] . " "
    //                 . "</h4></br>";
    //     echo "</p>";
    // }

} catch (PDOException $e) {
    echo "ERROR" . $e->getMessage();
}

function my_echo_p($string='')
{
    echo "<p>";
    echo "$string";
    echo "</p>";
}

 ?>