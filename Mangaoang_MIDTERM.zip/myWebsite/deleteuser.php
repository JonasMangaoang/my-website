<?php 
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (!empty($_POST['username']) 
        && !empty($_POST['password'])
        && !empty($_SESSION['username'])
        && !empty($_SESSION['password'])) {
        
        $id = $_SESSION['id'];
        $pusername = $_POST['username'];
        $ppassword = $_POST['password'];
        $susername = $_SESSION['username'];
        $spassword = $_SESSION['password'];

        if (($pusername==$susername)&&($ppassword==$spassword)) {
            //delete query
            $statement = $conn->prepare('DELETE FROM users WHERE id=:id');
            $statement->bindParam(':id',$id, PDO::PARAM_INT);
            $statement->execute();
            $statement = $conn->prepare('DELETE FROM pages WHERE id=:id');
            $statement->bindParam(':id',$id, PDO::PARAM_INT);
            $statement->execute();
            header("Location: logout.php");
        }
        else {
            header("Location: delete.php?message=Credentials did not match.");
        }
    }
    else {
        header("Location: delete.php?message=Incomplete credentials.");
    }
}
else {
    header("Location: delete.php?message=invalid access");
}
 
?>