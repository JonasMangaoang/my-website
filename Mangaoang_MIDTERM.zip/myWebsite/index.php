<?php 
include 'includes/header.php';

if (!empty($_GET['search'])) {
    $search = $_GET['search'];

    $statement = $conn->prepare('SELECT fname,mname,lname FROM pages
                                     WHERE fname LIKE :search
                                     OR    mname LIKE :search
                                     OR    lname LIKE :search');
    $statement->setFetchMode(PDO::FETCH_ASSOC);
    $statement->execute(array(
        'search' => $search . '%'
        ));
    $results = $statement->fetchAll();
}

 ?>
 <div>
     <ul class="w3-navbar w3-opacity w3-hover-opacity-off w3-medium">
        <li class="w3-left"  style="width:70% !important"><a href="index.php">Home</a></li>
        <li class="w3-right" style="width:15% !important"><a href="login.php">Login</a></li>
        <li class="w3-right" style="width:15% !important"><a href="signup.php">Sign Up</a></li>
     </ul>
 </div>
<div class="w3-content w3-center">
    <h1>Hello World!</h1> 
    <p>This is my first website</p>
    <form action="#">
        <input type="text" name="search" id="search" 
        placeholder="Search" style="text-align: center"><br>
        <input type="submit" name="submit" style="visibility: hidden;">
    </form>
    <?php 
        if (!empty($results)) {
            echo "Found " . sizeof($results) . " matches<br>";
            foreach ($results as $index => $result) {
                echo $result['fname'] . " " . $result['mname'] . " " . $result['lname'] . "<br>";
            }
        }
     ?>
</div>

<?php include 'includes/footer.php'; ?>