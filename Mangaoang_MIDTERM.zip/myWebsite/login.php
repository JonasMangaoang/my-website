<?php 
include 'includes/header.php'; 
if (is_logged_in()) {
    header("Location: userpage.php?message=already logged in.");
}
?>
 <div>
     <ul class="w3-navbar w3-opacity w3-hover-opacity-off w3-medium">
        <li class="w3-left"  style="width:70% !important"><a href="index.php">Home</a></li>
        <li class="w3-right" style="width:15% !important"><a href="login.php">Login</a></li>
        <li class="w3-right" style="width:15% !important"><a href="signup.php">Sign Up</a></li>
     </ul>
 </div>

<div class="w3-content w3-center" id="login">   
  <h1>Welcome Back!</h1>
  <?php if (!empty($message)) {echo "<div class='w3-red'><h5>$message</h5></div>";}?>  
  <form action="validateuser.php" method="post">
    <div class="field-wrap">
      <label for="username">
        Username<span class="req">*</span>
      </label>
      <input type="text" name="username" id="username" required autocomplete="off"/>
    </div>
    <div class="field-wrap">
      <label for="password">
        Password<span class="req">*</span>
      </label>
      <input type="password" name="password" id="password" required autocomplete="off"/>
    </div>
    <button type="submit" />Log In</button>
  </form>
</div>

<?php include 'includes/footer.php'; ?>