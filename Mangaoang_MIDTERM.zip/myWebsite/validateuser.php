<?php 
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if (!empty($_POST['username']) 
        && !empty($_POST['password'])) {
        
        #get values
        $username = $_POST['username'];
        $password = $_POST['password'];

        #validate user creds
        $statement = $conn->prepare('SELECT * FROM users
                                     WHERE username=:username AND password=:password');
        $statement->bindParam(':username',$username, PDO::PARAM_STR);
        $statement->bindParam(':password',$password, PDO::PARAM_STR);
        $statement->execute();
        $row = $statement->fetch();

        #login + set session
        if (!empty($row)) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['password'] = $row['password'];
            header("Location: userpage.php");
        }
        else {
            header("Location: login.php?message=No account found.");
        }
    }
}
else {
    header("Location: login.php?message=invalid access");
}
 
 ?>