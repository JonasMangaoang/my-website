<?php 
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    if(empty($_SESSION['id'])){
        header("Location: logout.php");
        die();
    }
    $id = $_SESSION['id'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $q1 = $_POST['a1'];
    $q2 = $_POST['a2'];
    $q3 = $_POST['a3'];
    $q4 = $_POST['a4'];
    $q5 = $_POST['a5'];
    $q6 = $_POST['a6'];
    $q7 = $_POST['a7'];
    $q8 = $_POST['a8'];
    $q9 = $_POST['a9'];
    $q10 = $_POST['a10'];

    #validate user creds
    $statement = $conn->prepare('SELECT * FROM users
                                 WHERE username=:username AND password=:password');
    $statement->bindParam(':username',$_SESSION['username'], PDO::PARAM_STR);
    $statement->bindParam(':password',$_SESSION['password'], PDO::PARAM_STR);
    $statement->execute();
    $row = $statement->fetch();

    if (!empty($row)) {
        if ($row['id'] == $id) {
        $statement = $conn->prepare('UPDATE pages SET fname=:fname,
                                                      mname=:mname,
                                                      lname=:lname,
                                                      q1=:q1,
                                                      q2=:q2,
                                                      q3=:q3,
                                                      q4=:q4,
                                                      q5=:q5,
                                                      q6=:q6,
                                                      q7=:q7,
                                                      q8=:q8,
                                                      q9=:q9,
                                                      q10=:q10
                                    WHERE id=:id');
        $statement->bindParam(':fname',$fname, PDO::PARAM_STR);
        $statement->bindParam(':mname',$mname, PDO::PARAM_STR);
        $statement->bindParam(':lname',$lname, PDO::PARAM_STR);
        $statement->bindParam(':q1',$q1, PDO::PARAM_STR);
        $statement->bindParam(':q2',$q2, PDO::PARAM_STR);
        $statement->bindParam(':q3',$q3, PDO::PARAM_STR);
        $statement->bindParam(':q4',$q4, PDO::PARAM_STR);
        $statement->bindParam(':q5',$q5, PDO::PARAM_STR);
        $statement->bindParam(':q6',$q6, PDO::PARAM_STR);
        $statement->bindParam(':q7',$q7, PDO::PARAM_STR);
        $statement->bindParam(':q8',$q8, PDO::PARAM_STR);
        $statement->bindParam(':q9',$q9, PDO::PARAM_STR);
        $statement->bindParam(':q10',$q10, PDO::PARAM_STR);
        $statement->bindParam(':id',$id, PDO::PARAM_STR);
        $statement->execute();
        header("Location: userpage.php?message=updated successfully.");
        // echo "updated successfully";
        }
        else {
            header("Location: login.php?message=invalid access.");
            // echo "session id and user id did not match";
        }
    }
    else {
        header("Location: login.php?message=invalid access.");
        // echo "invalid access no such user.";
    }
}
else {
    header("Location: login.php?message=invalid access");
    // echo "invalid access to direct url";
}
 
 ?>