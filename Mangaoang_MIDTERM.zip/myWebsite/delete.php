<?php 
include 'includes/header.php'; 
if (!is_logged_in()) {
    header("Location: login.php?message=user must be logged in to delete account.");
}
?>

<div class="w3-content" id="login">   
  <div>
    <h1>Are you sure you want leave us?</h1>
    <a href="userpage.php" style="color:green;">CANCEL</a>
  </div>
  <?php if (!empty($message)) {echo "<div class='w3-red'><h5>$message</h5></div>";}?>
  <p>Enter your credentials to delete account</p>  
  <form action="deleteuser.php" method="post">
    <div class="field-wrap">
      <label for="username">
        Username<span class="req">*</span>
      </label>
      <input type="text" name="username" id="username" required autocomplete="off"/>
    </div>
    <div class="field-wrap">
      <label for="password">
        Password<span class="req">*</span>
      </label>
      <input type="password" name="password" id="password" required autocomplete="off"/>
    </div>
    <button type="submit" />Confirm</button>
  </form>
</div>

<?php include 'includes/footer.php'; ?>