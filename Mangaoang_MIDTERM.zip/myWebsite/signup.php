<?php 
include ('includes/header.php');
if (is_logged_in()) {
    header("Location: userpage.php?message=logout before you signup");
}
?>
 <div>
     <ul class="w3-navbar w3-opacity w3-hover-opacity-off w3-medium">
        <li class="w3-left"  style="width:70% !important"><a href="index.php">Home</a></li>
        <li class="w3-right" style="width:15% !important"><a href="login.php">Login</a></li>
        <li class="w3-right" style="width:15% !important"><a href="signup.php">Sign Up</a></li>
     </ul>
 </div>

<div class="w3-content w3-center" id="signup">   
  <h1>Sign Up for Free</h1>
  <?php if (!empty($message)) {echo "<div class='w3-red'><h5>$message</h5></div>";}?>  
  <form action="adduser.php" method="post">
  <div class="top-row">
    <div class="field-wrap">
      <label for="username">
        User Name<span class="req">*</span>
      </label>
      <input type="text" id="username" name="username" required="true" />
    </div>
  </div>
  <div class="field-wrap">
    <label for="email_address">
      Email Address<span class="req">*</span>
    </label>
    <input type="email" id="email_address" name="email_address" required="true" />
  </div>
  <div class="field-wrap">
    <label for="password">
      Set A Password<span class="req">*</span>
    </label>
    <input type="password" id="password" name="password" required="true" />
  </div>
  <button type="submit">Get Started</button>
  </form>
</div>
      
<?php include 'includes/footer.php'; ?>